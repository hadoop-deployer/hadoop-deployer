if [ "$JAVA_HOME" = "" ]; then
    source $HOME/.bash_profile
fi
mkdir -p $HOME/mnt/dfs
rm -f $HOME/pkg/fuse-dfs/lib/libhdfs.so.0
if [ `uname -m | sed -e 's/i.86/32/'` == '32' ]; then
    export OS_ARCH=i386
    NATIVE=Linux-i386-32
    ln -s $HOME/pkg/fuse-dfs/lib/libhdfs.so.0.0.0.32b $HOME/pkg/fuse-dfs/lib/libhdfs.so.0
else
    export OS_ARCH=amd64
    NATIVE=Linux-amd64-64
    ln -s $HOME/pkg/fuse-dfs/lib/libhdfs.so.0.0.0.64b $HOME/pkg/fuse-dfs/lib/libhdfs.so.0
fi
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$HADOOP_HOME/lib/native/$NATIVE/:$HOME/pkg/fuse-dfs/lib
sh $HOME/pkg/fuse-dfs/fuse_dfs_wrapper.sh dfs://mob607:50900 $HOME/mnt/dfs -obig_writes -oprivate
