fusermount -u $HOME/mnt/dfs
